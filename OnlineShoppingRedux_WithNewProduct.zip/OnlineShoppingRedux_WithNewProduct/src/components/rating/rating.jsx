import React from "react";

function Rating(props) {
  let ratings = [];
  for (let index = 0; index < props.noofstars; index++) {
    ratings.push(
      <span style={{ color: "orange" }} key={index}>
        <i className="fa-solid fa-star"></i>
      </span>,
    );
  }
  return ratings;
}
export default Rating;
