import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { useParams } from "react-router-dom";
import { incrementLikes } from "../../redux/reducers/productsreducer";

function ProductDetails() {
  const { id } = useParams(); // read the parameter from the URL
  const products = useSelector((store) => store.products);
  const dispatch = useDispatch();
  const theProduct = products.find((product) => product.id == id);

  return (
    <div>
      <div className="row">
        <div className="col-md-8">
          <img src={theProduct.imageUrl} width="100%" />
        </div>
        <div className="col-md-4">
          <h2>{theProduct.title}</h2>
          <button
            className="btn btn-primary"
            onClick={() => dispatch(incrementLikes(theProduct.id))}
          >
            {theProduct.likes}
          </button>
        </div>
      </div>
    </div>
  );
}

export default ProductDetails;
