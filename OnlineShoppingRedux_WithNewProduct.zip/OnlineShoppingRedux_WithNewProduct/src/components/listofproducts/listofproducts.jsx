import React, { Component, useEffect, useState } from "react";
import Product from "../product/product";
import { useSelector } from "react-redux";
const ListOfProducts = () => {
  const products = useSelector((store) => store.products);

  return (
    <div className="row">
      {products.map((product) => (
        <Product productdetails={product} key={product.id} />
      ))}
    </div>
  );
};

export default ListOfProducts;
