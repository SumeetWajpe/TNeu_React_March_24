import React, { useState } from "react";
import Rating from "../rating/rating";
import { Link } from "react-router-dom";
import { useDispatch } from "react-redux";
import { deleteProduct, incrementLikes } from "../../redux/reducers/productsreducer";
const Product = (props) => {
  const dispatch = useDispatch();
  return (
    <div className="col-md-3 g-1">
      <div className="card">
        <Link to={"/productdetails/" + props.productdetails.id}>
          <img
            src={props.productdetails.imageUrl}
            alt={props.productdetails.title}
            className="card-img-top"
            height="200px"
          />
        </Link>

        <div className="card-body">
          <h5>{props.productdetails.title}</h5>
          <p>
            <Rating noofstars={props.productdetails.rating} />
          </p>
          <p> ₹.{props.productdetails.price}</p>
          <button
            className="btn btn-primary"
            onClick={() => dispatch(incrementLikes(props.productdetails.id))}
          >
            {props.productdetails.likes}
            <i className="fa-solid fa-thumbs-up"></i>
          </button>
          <button
            className="btn btn-danger mx-1"
            onClick={() => dispatch(deleteProduct(props.productdetails.id))}
          >
            X
          </button>
        </div>
      </div>
    </div>
  );
};

export default Product;
