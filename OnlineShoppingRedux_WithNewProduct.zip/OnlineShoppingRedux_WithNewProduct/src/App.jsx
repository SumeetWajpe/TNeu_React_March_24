import { BrowserRouter, Route, Routes } from "react-router-dom";
import "./App.css";
import ListOfProducts from "./components/listofproducts/listofproducts";
import ProductDetails from "./components/productdetails/productdetails";
import Navbar from "./components/navbar/navbar";
import NewProduct from "./components/newproduct/newproduct";

export default function App() {
  return (
    <BrowserRouter>
      <Navbar />
      <Routes>
        <Route path="/" Component={ListOfProducts}></Route>
        <Route path="/productdetails/:id" Component={ProductDetails}></Route>
        <Route path="/newproduct" Component={NewProduct}></Route>
      </Routes>
    </BrowserRouter>
  );
}
