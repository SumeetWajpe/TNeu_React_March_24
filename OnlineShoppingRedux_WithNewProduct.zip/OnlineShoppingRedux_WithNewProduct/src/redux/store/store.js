import { configureStore } from "@reduxjs/toolkit";
import products from "../reducers/productsreducer";
import posts from "../reducers/posts";

const store = configureStore({
  reducer: {
    products,
    posts,
  },
});
export default store;
