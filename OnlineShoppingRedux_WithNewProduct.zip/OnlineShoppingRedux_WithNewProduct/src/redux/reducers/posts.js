import { createSlice } from "@reduxjs/toolkit";
let initialState = [
  { id: 1, title: "FirstPost", body: "This is the first post" },
];
const postsslice = createSlice({
  name: "posts",
  initialState,
  reducers: {
    deletePost: (state, action) => {
      console.log("Within deletePost Reducer !");
      return state; // we must mutate the state (store) values & return the updated store data so that React (UI) updates.
    },
  },
});
export const { deletePost } = postsslice.actions;
export default postsslice.reducer;
