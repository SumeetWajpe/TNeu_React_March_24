export function SimpleFunctionalComponent(props) {
  return <h2>{props.msg} !</h2>;
}
