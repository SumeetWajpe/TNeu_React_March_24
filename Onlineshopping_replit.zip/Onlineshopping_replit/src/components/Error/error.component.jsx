import React from "react";

export default function Error() {
  return (
    <div>
      <h1 style={{ color: "red" }}>Page Not Found !</h1>
    </div>
  );
}
