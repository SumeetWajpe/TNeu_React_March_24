import React from "react";

function ProductDetails() {
  return <div>Within Product Details !</div>;
}

export default ProductDetails;
